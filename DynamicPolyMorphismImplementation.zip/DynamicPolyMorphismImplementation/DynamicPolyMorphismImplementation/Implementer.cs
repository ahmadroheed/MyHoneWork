﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DynamicPolyMorphismImplementation
{
    internal class Implementer
    {
        public void show2()
        {
            MessageBox.Show("show data");
            throw new NotImplementedException();
        }

        public void show3()
        {
            throw new NotImplementedException();
        }

        
    }
}
