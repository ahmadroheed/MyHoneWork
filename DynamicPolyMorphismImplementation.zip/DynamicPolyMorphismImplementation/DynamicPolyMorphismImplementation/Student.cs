﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DynamicPolyMorphismImplementation
{
    internal class Student
    {
        public  void show()
        {
           
            MessageBox.Show("this is a simple normal method inside normal class");
        }


    }
}
