﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DynamicPolyMorphismImplementation
{
    internal abstract class AbstractStudent
    {
        public abstract void save();
        public void delete()
        {
            MessageBox.Show("your data has been deleted.");
        }
    }

    internal abstract class AbstractStudent1
    {
        public abstract void save();
        public void delete()
        {
            MessageBox.Show("your data has been deleted.");
        }
    }

    internal class Extender : AbstractStudent

    {
        public override void save()
        {
            MessageBox.Show("your data has been saved.");
        }
    }
}
