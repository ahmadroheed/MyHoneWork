﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicPolyMorphismImplementation
{
    internal interface Interface1
    {
         void show1(int a, int b);
         void show2();
    }
}
